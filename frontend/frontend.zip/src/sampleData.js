// sampleData.js

const sampleData = [
  {
    id: 1,
    title: 'Перевозка Алматы → Астана',
    price: '120 000 ₸',
    description: 'Груз: бытовая техника, до 5 тонн',
  },
  {
    id: 2,
    title: 'Перевозка Бишкек → Москва',
    price: '300 000 ₽',
    description: 'Груз: текстиль, 10 тонн',
  },
  {
    id: 3,
    title: 'Перевозка Минск → Санкт-Петербург',
    price: '2000 $',
    description: 'Груз: мебель, 15 тонн',
  },
];

// Убедитесь, что есть экспорт по умолчанию
export default sampleData;